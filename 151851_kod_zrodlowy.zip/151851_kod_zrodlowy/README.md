# Odkrywanie zależności między obiektami w bazie danych — kod źródłowy

Załącznik do pracy magisterskiej.
Autorka: Maria Nowicka (151851), Politechnika Poznańska, Wydział Informatyki
i Telekomunikacji. Promotor: prof. dr hab. inż. Robert Wrembel. Rok 2026.

Archiwum zawiera implementację metod detekcji tabel o zerwanym lineage
(*broken lineage*) na podstawie samej topologii grafu pochodzenia danych,
skrypty eksperymentów oraz testy jednostkowe. Opis metod i wyniki znajdują się
w tekście pracy.

## Zawartość

```
src/
  detection/     detekcja zainfekowanych węzłów (główna część pracy)
                   job_removal.py        symulacja broken lineage (usuwanie jobów)
                   node_features.py      cechy topologiczne węzła
                   completeness.py       heurystyka peer-consistency
                   node_classifier.py    heurystyki i klasyfikatory ML (RF, RUSBoost, LightGBM)
                   lineage_detector.py   LineageDetector (RF + cechy kompletności + kalibracja)
                   node_metrics.py       metryki rankingowe
                   run_*.py              skrypty eksperymentów
  data/          wczytywanie grafów DLG-DG-23, podziały danych, adapter grafu zewnętrznego
  algorithms/    badanie wstępne: heurystyki link prediction, klasyczne ML, Node2Vec + MLP
  evaluation/    metryki badania wstępnego
scripts/         agregacja wyników, testy istotności, ważność cech, tabele i rysunki
tests/           testy jednostkowe (pytest)
requirements.txt
```

## Wymagania

Python 3.10.

```bash
pip install -r requirements.txt
```

## Dane

Dane nie są częścią archiwum. Są potrzebne zarówno do eksperymentów, jak i do
większości testów jednostkowych, które korzystają z rzeczywistych grafów.

1. **DLG-DG-23** (Chen i in., *An open dataset of data lineage graphs for data
   governance research*, Visual Informatics 2024):
   <https://github.com/csuvis/DataAssetGraphData>.
   Pliki z archiwów `Node.rar` i `Edge.rar` należy wypakować do
   `data/raw/extracted/Node/` oraz `data/raw/extracted/Edge/`
   (np. `data/raw/extracted/Node/DLG1-node.json`).
2. **Graf zewnętrzny** do testu cross-dataset (tylko `run_cross_dataset*.py`):
   pliki `train_DataLineage.csv` i `test_DataLineage.csv` z repozytorium
   <https://github.com/dudenzz/lineage>, umieszczone w
   `data/external/dutkiewicz/`.

## Uruchomienie

Wszystkie polecenia wykonuje się z katalogu głównego archiwum.

```bash
# Testy jednostkowe
python -m pytest tests

# Eksperyment główny: protokół indukcyjny leave-one-graph-out, wariant uczciwy
python -m src.detection.run_detection_experiments --all --exclude-isolated \
    --removal-ratio 0.10 --repeats 3 --seed 42 --csv results/wyniki_detekcja_canon.csv

# Wariant bez wykluczenia węzłów izolowanych
python -m src.detection.run_detection_experiments --all \
    --removal-ratio 0.10 --repeats 3 --seed 42 --csv results/wyniki_detekcja_napompowany.csv

# Agregacja wyników do tabel CSV i LaTeX
python scripts/aggregate_detection.py

# Eksperymenty uzupełniające
python -m src.detection.run_removal_sensitivity
python -m src.detection.run_ablation
python -m src.detection.run_transductive
python -m src.detection.run_scale_generalization
python -m src.detection.run_cross_dataset
python scripts/test_istotnosci.py
python scripts/waznosc_cech.py
```

Wyniki zapisywane są w katalogu `results/`. Eksperymenty są deterministyczne
przy ustalonym ziarnie (`--seed 42`, domyślnie).
