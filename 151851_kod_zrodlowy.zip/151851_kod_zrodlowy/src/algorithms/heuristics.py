"""
Heurystyczne algorytmy predykcji krawędzi (link prediction).

Wszystkie metody operują na nieskierowanej wersji grafu treningowego.

Metody klasyczne (wymagają wspólnych sąsiadów):
    - Common Neighbors (CN)  — liczba wspólnych sąsiadów
    - Jaccard Coefficient    — CN / |N(u) ∪ N(v)|
    - Adamic-Adar            — Σ 1/log(deg(w)) dla wspólnych sąsiadów w

Uwaga: DATA_FLOW w DLG-DG-23 tworzy graf bipartytowy (Table↔Job).
Dla par (Table, Job) sąsiedztwa N(u) i N(v) są zawsze rozłączne
(N(Table) = {Jobs+Fields}, N(Job) = {Tables}), więc CN/Jaccard/AA = 0.
Poniższe metody działają poprawnie na grafach bipartytowych:

    - Preferential Attachment (PA) — deg(u) × deg(v), nie wymaga wspólnych sąsiadów
    - L3 (ścieżki długości 3)      — liczba ścieżek Table→Job→Table→Job
                                     odpowiednik CN na rzucie bipartytowym
    - Katz Index                   — Σ β^l * |spacery długości l od u do v|
                                     uogólnienie L3 na wszystkie długości ścieżek;
                                     dla par bipartytowych liczy l=1,3,5,...
    - PPR (Personalized PageRank)  — prawdopodobieństwo odwiedzenia v przez
                                     random walk startujący z u (α=0.85);
                                     naturalnie bipartytowy, captures global structure
"""

import math
from collections import defaultdict

import networkx as nx
import numpy as np


ALL_METHODS = [
    "common_neighbors",
    "jaccard",
    "adamic_adar",
    "preferential_attachment",
    "rwpa",
    "l3",
    "katz",
    "ppr",
]


def score_edges(
    G_train: nx.DiGraph,
    edges: list[tuple],
    method: str = "preferential_attachment",
) -> np.ndarray:
    """
    Oblicza heurystyczny score dla listy par węzłów.

    Parameters
    ----------
    G_train : nx.DiGraph
        Graf treningowy (z usuniętymi krawędziami testowymi).
    edges : list of (u, v)
        Pary węzłów do oceny.
    method : str
        Jedna z: "common_neighbors", "jaccard", "adamic_adar",
                 "preferential_attachment", "l3"

    Returns
    -------
    np.ndarray, shape (len(edges),)
        Score dla każdej pary — wyższy = bardziej prawdopodobna krawędź.
    """
    if method == "ppr":
        return _ppr_batch(G_train.to_undirected(), edges)

    if method == "rwpa":
        G_und = G_train.to_undirected()
        return np.array([_rwpa(G_train, G_und, u, v) for u, v in edges])

    _METHODS = {
        "common_neighbors":        _common_neighbors,
        "jaccard":                 _jaccard,
        "adamic_adar":             _adamic_adar,
        "preferential_attachment": _preferential_attachment,
        "l3":                      _l3,
        "katz":                    _katz,
    }
    if method not in _METHODS:
        raise ValueError(
            f"Nieznana metoda: '{method}'. Dozwolone: {list(_METHODS.keys())}"
        )

    G_undirected = G_train.to_undirected()
    scorer = _METHODS[method]
    return np.array([scorer(G_undirected, u, v) for u, v in edges])


def score_all_methods(
    G_train: nx.DiGraph,
    edges: list[tuple],
) -> dict[str, np.ndarray]:
    """
    Oblicza scores dla wszystkich pięciu heurystyk naraz.

    Returns
    -------
    dict {method_name: np.ndarray}
    """
    G_und = G_train.to_undirected()
    return {
        "common_neighbors":        np.array([_common_neighbors(G_und, u, v)        for u, v in edges]),
        "jaccard":                 np.array([_jaccard(G_und, u, v)                 for u, v in edges]),
        "adamic_adar":             np.array([_adamic_adar(G_und, u, v)             for u, v in edges]),
        "preferential_attachment": np.array([_preferential_attachment(G_und, u, v) for u, v in edges]),
        "rwpa":                    np.array([_rwpa(G_train, G_und, u, v)           for u, v in edges]),
        "l3":                      np.array([_l3(G_und, u, v)                      for u, v in edges]),
        "katz":                    np.array([_katz(G_und, u, v)                    for u, v in edges]),
        "ppr":                     _ppr_batch(G_und, edges),
    }


# Implementacje poszczególnych heurystyk

def _neighbors(G: nx.Graph, node) -> set:
    """Zbiór sąsiadów węzła (z wykluczeniem samego siebie)."""
    return set(G.neighbors(node)) - {node}


def _common_neighbors(G: nx.Graph, u, v) -> float:
    """Liczba wspólnych sąsiadów."""
    if not (G.has_node(u) and G.has_node(v)):
        return 0.0
    return float(len(_neighbors(G, u) & _neighbors(G, v)))


def _jaccard(G: nx.Graph, u, v) -> float:
    """Jaccard Coefficient: |N(u) ∩ N(v)| / |N(u) ∪ N(v)|."""
    if not (G.has_node(u) and G.has_node(v)):
        return 0.0
    nu, nv = _neighbors(G, u), _neighbors(G, v)
    union = nu | nv
    if not union:
        return 0.0
    return len(nu & nv) / len(union)


def _adamic_adar(G: nx.Graph, u, v) -> float:
    """Adamic-Adar: Σ 1/log(deg(w)) dla w ∈ N(u) ∩ N(v)."""
    if not (G.has_node(u) and G.has_node(v)):
        return 0.0
    common = _neighbors(G, u) & _neighbors(G, v)
    score = 0.0
    for w in common:
        deg = G.degree(w)
        if deg > 1:
            score += 1.0 / math.log(deg)
    return score


def _preferential_attachment(G: nx.Graph, u, v) -> float:
    """
    Preferential Attachment: deg(u) × deg(v).

    Nie wymaga wspólnych sąsiadów — działa poprawnie na grafach bipartytowych.
    Założenie: węzły o wyższym stopniu mają wyższe prawdopodobieństwo nowych połączeń.
    """
    if not (G.has_node(u) and G.has_node(v)):
        return 0.0
    return float(G.degree(u) * G.degree(v))


def _l3(G: nx.Graph, u, v) -> float:
    """
    L3 — liczba ścieżek długości 3 między u i v.

    Odpowiednik Common Neighbors na rzucie bipartytowym.
    Dla pary (Table, Job): liczy ścieżki Table→Job'→Table'→Job,
    czyli ile "alternatywnych tras" łączy u z v przez dwa węzły pośrednie.

    Złożoność: O(deg(u) × max_deg²) — może być kosztowna na dużych grafach.
    """
    if not (G.has_node(u) and G.has_node(v)):
        return 0.0
    count = 0
    for w in _neighbors(G, u):           # u → w (hop 1)
        for x in _neighbors(G, w):        # w → x (hop 2)
            if x != u and v in _neighbors(G, x):   # x → v (hop 3)
                count += 1
    return float(count)


def _katz(G: nx.Graph, u, v, beta: float = 0.005, max_len: int = 6) -> float:
    """
    Katz Index — suma ważonych spacerów wszystkich długości od u do v.

    Katz(u,v) = Σ_{l=1}^{max_len} β^l × |spacery długości l od u do v|

    Implementacja BFS zlicza spacery (walks), nie proste ścieżki — zgodnie
    ze standardową definicją indeksu Katza (odpowiednik potęg macierzy A).

    Działa na grafach bipartytowych:
    - dla par (Table, Job) jedynie spacery nieparzystej długości (l=1,3,5,...)
      mają niezerową liczbę — co czyni Katz naturalnym rozszerzeniem L3.

    Parameters
    ----------
    beta : float
        Współczynnik tłumienia (domyślnie 0.005).
        Musi być < 1/λ_max(A) dla zbieżności nieskończonej sumy.
        Przy wartości 0.005 l=3 wnosi β³ = 1.25×10⁻⁷ × liczba_ścieżek,
        więc dłuższe ścieżki mają realny wpływ przy gęstszych grafach.
    max_len : int
        Maksymalna rozważana długość spaceru (domyślnie 6).
    """
    if not (G.has_node(u) and G.has_node(v)):
        return 0.0

    # frontier[node] = liczba spacerów aktualnej długości kończących się w node
    frontier: dict = {u: 1}
    total = 0.0
    beta_l = beta  # β^l dla aktualnego l

    for _ in range(max_len):
        next_frontier: dict = defaultdict(int)
        for node, cnt in frontier.items():
            for nb in G.neighbors(node):
                next_frontier[nb] += cnt
        total += beta_l * next_frontier.get(v, 0)
        beta_l *= beta
        frontier = dict(next_frontier)

    return total


def _role_weight(G: nx.DiGraph, node) -> float:
    """Waga roli węzła w potoku ETL na podstawie stopni DATA_FLOW."""
    df_in  = sum(1 for _, _, d in G.in_edges(node,  data=True)
                 if d.get("relation_type") == "DATA_FLOW")
    df_out = sum(1 for _, _, d in G.out_edges(node, data=True)
                 if d.get("relation_type") == "DATA_FLOW")
    if df_in > 0 and df_out > 0:
        return 2.0   # intermediate / staging (grid search opt.)
    elif df_in == 0 and df_out > 0:
        return 0.75  # source (grid search opt.)
    elif df_in > 0 and df_out == 0:
        return 1.0   # sink
    return 0.5       # isolated


def _rwpa(G_directed: nx.DiGraph, G_und: nx.Graph, u, v) -> float:
    """
    Role-Weighted Preferential Attachment (RWPA).

    RWPA(u,v) = role_weight(u) × role_weight(v) × deg(u) × deg(v)

    Rozszerza PA o wagi ról ETL: węzły intermediate (staging tables) mają
    trzykrotnie wyższy priorytet niż sink, bo to one znikają jako tymczasowe
    i generują broken lineage. Zachowuje wszystkie właściwości PA (brak
    wymagania wspólnych sąsiadów, działa na grafach bipartytowych).
    """
    if not (G_directed.has_node(u) and G_directed.has_node(v)):
        return 0.0
    return (_role_weight(G_directed, u) *
            _role_weight(G_directed, v) *
            float(G_und.degree(u) * G_und.degree(v)))


def _ppr_batch(G: nx.Graph, edges: list[tuple], alpha: float = 0.85) -> np.ndarray:
    """
    Personalized PageRank (PPR) — batch obliczenie dla listy par krawędzi.

    PPR(u→v) = prawdopodobieństwo odwiedzenia v przez random walk startujący
    z u z restart probability (1-α).

    Działa na grafach bipartytowych (random walk nie wymaga wspólnych sąsiadów).
    Captures global structure grafu — węzły "centralnie położone" w tym samym
    komponencie dostają wyższy score.

    Implementacja batch: dla każdego unikalnego węzła źródłowego nx.pagerank()
    jest wywoływany raz, wyniki cache'owane dla wszystkich par z tym źródłem.

    Złożoność: O(|unikalnych_u| × n × iteracje_pagerank)
    """
    unique_sources = set(u for u, _ in edges)
    ppr_cache: dict = {}

    for u in unique_sources:
        if G.has_node(u):
            ppr_cache[u] = nx.pagerank(
                G, alpha=alpha, personalization={u: 1.0}, max_iter=200
            )
        else:
            ppr_cache[u] = {}

    return np.array([
        ppr_cache.get(u, {}).get(v, 0.0)
        for u, v in edges
    ])
